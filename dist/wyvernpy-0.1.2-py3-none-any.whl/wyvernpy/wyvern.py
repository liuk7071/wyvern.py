import requests
from wyvernpy import wyvern_server, wyvern_member
import json
import ast

class wyvern_session:
    __slots__ = ("id", "token")

    def __init__(self, id: str, token: str):
        self.id = id
        self.token = token
        session_check = requests.get("http://78.141.209.47:3030/api/getuser?token=" + token)
        if session_check.status_code == 200:
            if session_check.json()[2] == id:
                print("Ready")
            else:
                raise Exception("Invalid Wyvern ID")
        else:
            raise Exception("Invalid token")


    def getServers(self, _token = None):
        try:
            if _token != None:
                servers = requests.get("http://78.141.209.47:3030/api/getserversfromuser?token=" + _token)
                servers = servers.json()[0]
                _servers = ast.literal_eval(servers)
                return _servers
            else:
                servers = requests.get("http://78.141.209.47:3030/api/getserversfromuser?token=" + self.token)
                servers = servers.json()[0]
                _servers = ast.literal_eval(servers)
                return _servers
        except:
            raise Exception("Failed to retreive servers from user with error code " + str(servers.status_code))

    def getServer(self, server_id: str):
        try:
            server_json = requests.get("http://78.141.209.47:3030/api/getserver?serverid=" + server_id)
            return wyvern_server.server(server_json.json()[0])
        except:
            raise Exception("Failed to retreive server with error code " + str(server_json.status_code))
    
    def getUser(self, user_id = None):
        try:
            if user_id != None:
                user_json = requests.get("http://78.141.209.47:3030/api/getuserinfo?wyvernid=" + user_id)
                return wyvern_member.member(user_json.json())
            else:
                user_json = requests.get("http://78.141.209.47:3030/api/getuserinfo?wyvernid=" + self.id)
                return wyvern_member.member(user_json.json())
        except:
            raise Exception("Failed to retreive user info with error code " + str(user_json.status_code))